echo "*****************BF 4G";
/usr/bin/time -o time_bf_21_4G.txt /data/alimasse/miniconda/bin/kmtricks pipeline --file all_datasets_21.fof --run-dir ./index_4G_all_21_bf --kmer-size 21 --mode hash:bft:bin --hard-min 1 --soft-min 1  --share-min 1 --skip-merge --bloom-size 4294967296 --bf-format howdesbt --cpr;

echo "*****************INDEX 4G";
/usr/bin/time -o time_howde_21_4G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./index_4G_all_21_bf --howde;

echo "*****************BF 8G";
/usr/bin/time -o time_bf_21_8G.txt /data/alimasse/miniconda/bin/kmtricks pipeline --file all_datasets_21.fof --run-dir ./index_8G_all_21_bf --kmer-size 21 --mode hash:bft:bin --hard-min 1 --soft-min 1  --share-min 1 --skip-merge --bloom-size 8589934592 --bf-format howdesbt --cpr;

echo "*****************INDEX 8G";
/usr/bin/time -o time_howde_21_8G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./index_8G_all_21_bf --howde;

#antoine's rna-seq
echo "*****************BF 256";
/usr/bin/time -o time_bf_256.txt /data/alimasse/miniconda/bin/kmtricks pipeline --file fastafof256.fof --run-dir ./index_256_all_31_bf_4G --kmer-size 31 --mode hash:bft:bin --soft-min 1  --share-min 1 --skip-merge --bloom-size 4000000000 --bf-format howdesbt --cpr -t 12;
echo "*****************done BF 256";
echo "*****************INDEX 256";
/usr/bin/time -o time_howde_256_4G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./index_256_all_31_bf_4G --howde -t 12;
echo "*****************done INDEX 256";


echo "*****************BF 512";
/usr/bin/time -o time_bf_512.txt /data/alimasse/miniconda/bin/kmtricks pipeline --file fastafof512.fof --run-dir ./index_512_all_31_bf_4G --kmer-size 31 --mode hash:bft:bin --soft-min 1  --share-min 1 --skip-merge --bloom-size 4000000000 --bf-format howdesbt --cpr -t 12;
echo "*****************done BF 512";
echo "*****************INDEX 512";
/usr/bin/time -o time_howde_512_4G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./index_512_all_31_bf_4G --howde -t 12;
echo "*****************done INDEX 512";

echo "*****************BF 1024";
/usr/bin/time -o time_bf_1024.txt /data/alimasse/miniconda/bin/kmtricks pipeline --file fastafof1024.fof --run-dir ./index_1024_all_31_bf_4G --kmer-size 31 --mode hash:bft:bin --soft-min 1  --share-min 1 --skip-merge --bloom-size 4000000000 --bf-format howdesbt --cpr -t 12;
echo "*****************done BF 1024";
echo "*****************INDEX 1024";
/usr/bin/time -o time_howde_1024_4G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./index_1024_all_31_bf_4G --howde -t 12;
echo "*****************done INDEX 1024";

#original files of files
#/data/alimasse/massive_RNA/aspera_fold/fastafof256.txt
#/data/alimasse/massive_RNA/aspera_fold/fastafof512.txt
#/data/alimasse/massive_RNA/aspera_fold/fastafof1024.txt


#canon benchmark 0.5

echo "*****************BF 2G";
/usr/bin/time -o time_bf_21_2G.txt /data/alimasse/miniconda/bin/kmtricks pipeline --file all_datasets_21.fof --run-dir ./index_2G_all_21_bf --kmer-size 21 --mode hash:bft:bin --hard-min 1 --soft-min 1  --share-min 1 --skip-merge --bloom-size 2147483648 --bf-format howdesbt --cpr;
echo "***************** done BF 2G";
echo "*****************INDEX 2G";
/usr/bin/time -o time_howde_21_2G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./index_2G_all_21_bf --howde;
echo "*****************done INDEX 2G";

echo "*****************INDEX 2G";
/usr/bin/time -o time_howde_21_2G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./index_2G_all_21_bf --howde;
echo "*****************done INDEX 2G";


echo "*****************BF 2048";
/usr/bin/time -o time_bf_2048.txt /data/alimasse/miniconda/bin/kmtricks pipeline --file fastafof2048.fof --run-dir ./index_2048_all_31_bf_4G --kmer-size 31 --mode hash:bft:bin --soft-min 1  --share-min 1 --skip-merge --bloom-size 4000000000 --bf-format howdesbt --cpr -t 12;
echo "*****************done BF 2048";
echo "*****************INDEX 2048";
/usr/bin/time -o time_howde_2048_4G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./index_2048_all_31_bf_4G --howde -t 12;
echo "*****************done INDEX 2048";
echo "*****************BF 4096";
/usr/bin/time -o time_bf_4096.txt /data/alimasse/miniconda/bin/kmtricks pipeline --file fastafof4096.fof --run-dir ./new_index_4096_all_31_bf_4G --kmer-size 31 --mode hash:bft:bin --soft-min 1  --share-min 1 --skip-merge --bloom-size 4000000000 --bf-format howdesbt --cpr -t 12;
echo "*****************done BF 4096";
echo "*****************INDEX 4096";
/usr/bin/time -o time_howde_4096_4G.txt /data/alimasse/miniconda/bin/kmtricks index --run-dir ./new_index_4096_all_31_bf_4G --howde -t 12;
echo "*****************done INDEX 4096";

#/usr/bin/time -o time_query_sbt_4G_1k.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_4G_all_21_bf --query unitigs_1k_query.fa --threshold 0.8 --sort > results_sbt_query_unitigs_1k_4Gindex.txt

#/usr/bin/time -o time_query_sbt_8G_1k.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_8G_all_21_bf --query unitigs_1k_query.fa --threshold 0.8 --sort > results_sbt_query_unitigs_1k_8Gindex.txt


#100 sequences
echo "query 100 2G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_2G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_2G_100.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_2G_all_21_bf --query batch_query100.fa --threshold 0.8 --sort > results_sbt_query_unitigs_100_2Gindex.txt;
echo "done 100 2G index\n query 100 4G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_4G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_4G_100.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_4G_all_21_bf --query batch_query100.fa --threshold 0.8 --sort > results_sbt_query_unitigs_100_4Gindex.txt;
echo "done 100 4G index\n query 1k 8G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_8G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_8G_100.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_8G_all_21_bf --query batch_query100.fa --threshold 0.8 --sort > results_sbt_query_unitigs_100_8Gindex.txt;
"done 100 8G index";


#1k sequences
echo "query 1k 2G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_2G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_2G_1k.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_2G_all_21_bf --query batch_query1k.fa --threshold 0.8 --sort > results_sbt_query_unitigs_1k_2Gindex.txt;
echo "done 1k 2G index\n query 1k 4G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_4G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_4G_1k.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_4G_all_21_bf --query batch_query1k.fa --threshold 0.8 --sort > results_sbt_query_unitigs_1k_4Gindex.txt;
echo "done 1k 4G index\n query 1k 8G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_8G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_8G_1k.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_8G_all_21_bf --query batch_query1k.fa --threshold 0.8 --sort > results_sbt_query_unitigs_1k_8Gindex.txt;
"done 1k 8G index";

#10k sequences
echo "query 10k 2G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_2G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_2G_10k.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_2G_all_21_bf --query batch_query10k.fa --threshold 0.8 --sort > results_sbt_query_unitigs_10k_2Gindex.txt;
echo "done 10k 2G index\n query 10k 4G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_4G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_4G_10k.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_4G_all_21_bf --query batch_query10k.fa --threshold 0.8 --sort > results_sbt_query_unitigs_10k_4Gindex.txt;
echo "done 1k 4G index\n query 10k 8G index";
#warm cache
/data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_8G_all_21_bf --query batch_query1.fa --threshold 0.8 --sort > null;
/usr/bin/time -o time_query_sbt_8G_10k.txt /data/alimasse/miniconda/bin/kmtricks query --run-dir ./index_8G_all_21_bf --query batch_query10k.fa --threshold 0.8 --sort > results_sbt_query_unitigs_10k_8Gindex.txt;
"done 10k 8G index";

